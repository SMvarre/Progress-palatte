document.addEventListener("DOMContentLoaded", () => {
  const scorePercentage = localStorage.getItem("scorePercentage");
  const correctAnswers = localStorage.getItem("correctAnswers");
  const totalQuestions = localStorage.getItem("totalQuestions");
  const resultMessage = localStorage.getItem("resultMessage");

  // Display the results
  document.getElementById("score-percentage").textContent = `${scorePercentage}%`;
  document.getElementById("result-message").textContent = resultMessage;
  document.getElementById("result-details").textContent = `You answered ${correctAnswers} out of ${totalQuestions} questions correctly.`;
});

function restartQuiz() {
  // Redirect back to the main page to restart the quiz
  window.location.href = "index.html";
}